using BasicMath;

namespace BasicMath.Test
{
    public class Tests
    {
        private MathOperations mathOperations;

        [SetUp]
        public void Setup()

        {

            mathOperations = new MathOperations();

        }

        [Test]
        public void TestAddEightPlusNine()

        {

            double Expected = 17;
            double Actual = mathOperations.Add(8, 9);
            Assert.AreEqual(Expected, Actual);

        }

        [Test]
        public void TestNineSubtractEight()

        { 

            double Expected = 1;
            double Actual = mathOperations.Subtract(9, 8);
            Assert.AreEqual(Expected, Actual);

        }

        [Test]
        public void TestTwoMultiplyTwo()

        { 

            double Expected = 4;
            double Actual = mathOperations.Multiply(2, 2);
            Assert.AreEqual(Expected, Actual);

        }

        [Test]
        public void TestTwoDivideTwo()

        { 

            double Expected = 1;
            double Actual = mathOperations.Divide(2, 2);
            Assert.AreEqual(Expected, Actual);

        }
        
    }   
}